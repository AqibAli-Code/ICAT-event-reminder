/**
 * AppHeader - Navigation header for the application.
 * Shows user info and navigation links.
 */

import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { signOut } from "@/lib/supabase-helpers";
import { Bell, LogOut, Shield, CalendarDays } from "lucide-react";

const AppHeader = () => {
  const { user, isAdmin } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleSignOut = async () => {
    await signOut();
    navigate("/auth");
  };

  const isAdminRoute = location.pathname.startsWith("/admin");

  return (
    <header className="sticky top-0 z-50 border-b bg-card/80 backdrop-blur-sm">
      <div className="container flex h-14 items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
            <Bell className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="font-semibold text-foreground">Event Reminder</span>
        </div>
        <div className="flex items-center gap-2">
          {isAdmin && (
            <Button
              variant={isAdminRoute ? "secondary" : "ghost"}
              size="sm"
              onClick={() => navigate(isAdminRoute ? "/" : "/admin")}
            >
              {isAdminRoute ? (
                <>
                  <CalendarDays className="h-4 w-4 mr-1" />
                  My Events
                </>
              ) : (
                <>
                  <Shield className="h-4 w-4 mr-1" />
                  Admin
                </>
              )}
            </Button>
          )}
          <span className="text-sm text-muted-foreground hidden sm:inline">
            {user?.email}
          </span>
          <Button variant="ghost" size="icon" onClick={handleSignOut} title="Sign out">
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  );
};

export default AppHeader;
