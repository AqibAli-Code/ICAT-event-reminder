/**
 * EventForm - Form for creating/editing events.
 * Used in both create and edit modes.
 */

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { fetchCategories, createEvent, updateEvent, EventData } from "@/lib/supabase-helpers";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { CalendarDays, Clock, AlignLeft, Tag, Type, Loader2, CalendarPlus, Edit3 } from "lucide-react";

interface Category {
  id: string;
  name: string;
}

interface EventFormProps {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
  editEvent?: EventData & { id: string } | null;
}

const EventForm = ({ open, onClose, onSaved, editEvent }: EventFormProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [categories, setCategories] = useState<Category[]>([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [eventDate, setEventDate] = useState("");
  const [eventTime, setEventTime] = useState("");
  const [categoryId, setCategoryId] = useState<string>("");
  const [loading, setLoading] = useState(false);

  // Load categories on mount
  useEffect(() => {
    fetchCategories().then(({ data }) => {
      if (data) setCategories(data);
    });
  }, []);

  // Populate form when editing
  useEffect(() => {
    if (editEvent) {
      setTitle(editEvent.title);
      setDescription(editEvent.description || "");
      const date = new Date(editEvent.event_date);
      setEventDate(date.toISOString().split("T")[0]);
      setEventTime(date.toTimeString().slice(0, 5));
      setCategoryId(editEvent.category_id || "");
    } else {
      setTitle("");
      setDescription("");
      setEventDate("");
      setEventTime("");
      setCategoryId("");
    }
  }, [editEvent, open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);

    const eventDatetime = new Date(`${eventDate}T${eventTime}`).toISOString();
    const eventPayload = {
      title: title.trim(),
      description: description.trim() || undefined,
      event_date: eventDatetime,
      category_id: categoryId || null,
      user_id: user.id,
    };

    try {
      if (editEvent) {
        const { error } = await updateEvent(editEvent.id, eventPayload);
        if (error) throw error;
        toast({ title: "Event updated successfully!" });
      } else {
        const { error } = await createEvent(eventPayload);
        if (error) throw error;
        toast({ title: "Event created successfully!" });
      }
      onSaved();
      onClose();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

 return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] p-0 overflow-hidden border-slate-200 shadow-xl rounded-lg font-sans">
        
        {/* Minimalist Header */}
        <DialogHeader className="px-6 py-6 bg-white border-b border-slate-100 m-0">
          <DialogTitle className="text-xl font-semibold text-slate-900 tracking-tight">
            {editEvent ? "Edit Event" : "Create New Event"}
          </DialogTitle>
          <DialogDescription className="text-sm text-slate-500 mt-1">
            {editEvent ? "Update the details of your scheduled event below." : "Fill out the required fields to schedule a new event."}
          </DialogDescription>
        </DialogHeader>

        {/* Crisp, Structured Form Body */}
        <form onSubmit={handleSubmit} className="flex flex-col bg-slate-50/30">
          <div className="px-6 py-6 space-y-6">
            
            {/* Title */}
            <div className="space-y-2">
              <Label htmlFor="title" className="text-sm font-medium text-slate-700">
                Event Title <span className="text-red-500">*</span>
              </Label>
              <Input 
                id="title" 
                value={title} 
                onChange={(e) => setTitle(e.target.value)} 
                placeholder="e.g., Final Presentation" 
                required 
                maxLength={100} 
                className="bg-white border-slate-300 focus-visible:ring-1 focus-visible:ring-slate-900 focus-visible:border-slate-900 rounded-md shadow-sm h-10" 
              />
            </div>

            {/* Category */}
            <div className="space-y-2">
              <Label htmlFor="category" className="text-sm font-medium text-slate-700">
                Category
              </Label>
              <Select value={categoryId} onValueChange={setCategoryId}>
                <SelectTrigger className="bg-white border-slate-300 focus:ring-1 focus:ring-slate-900 rounded-md shadow-sm h-10">
                  <SelectValue placeholder="Select a category..." />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Date & Time Row */}
            <div className="grid grid-cols-2 gap-5">
              <div className="space-y-2">
                <Label htmlFor="date" className="text-sm font-medium text-slate-700">
                  Date <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <CalendarDays className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                  <Input 
                    id="date" 
                    type="date" 
                    value={eventDate} 
                    onChange={(e) => setEventDate(e.target.value)} 
                    required 
                    className="pl-9 bg-white border-slate-300 focus-visible:ring-1 focus-visible:ring-slate-900 rounded-md shadow-sm h-10 w-full" 
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="time" className="text-sm font-medium text-slate-700">
                  Time <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                  <Input 
                    id="time" 
                    type="time" 
                    value={eventTime} 
                    onChange={(e) => setEventTime(e.target.value)} 
                    required 
                    className="pl-9 bg-white border-slate-300 focus-visible:ring-1 focus-visible:ring-slate-900 rounded-md shadow-sm h-10 w-full" 
                  />
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description" className="text-sm font-medium text-slate-700">
                Description
              </Label>
              <Textarea 
                id="description" 
                value={description} 
                onChange={(e) => setDescription(e.target.value)} 
                placeholder="Add any study notes, links, or location details here..." 
                maxLength={500} 
                rows={4} 
                className="bg-white border-slate-300 focus-visible:ring-1 focus-visible:ring-slate-900 rounded-md shadow-sm resize-none" 
              />
            </div>
            
          </div>

          {/* Minimalist Footer */}
          <div className="px-6 py-4 bg-white border-t border-slate-200 flex gap-3 justify-end items-center">
            <Button type="button" variant="ghost" onClick={onClose} className="text-slate-600 hover:bg-slate-100 hover:text-slate-900 font-medium">
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={loading} 
              className="bg-slate-900 text-white hover:bg-slate-800 shadow-sm font-medium px-6 h-10 transition-colors"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : editEvent ? (
                "Save Changes"
              ) : (
                "Create Event"
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default EventForm;