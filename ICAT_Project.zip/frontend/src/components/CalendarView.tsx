/**
 * CalendarView - Enterprise Edition
 * High-contrast grid, crisp typography, and professional color-coding.
 */

import { useState, useMemo } from "react";
import {
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  format,
  isSameMonth,
  isSameDay,
  isToday,
  addMonths,
  subMonths,
} from "date-fns";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Clock, Calendar as CalendarIcon } from "lucide-react";

interface CalendarEvent {
  id: string;
  title: string;
  event_date: string;
  categories?: { name: string } | null;
}

interface CalendarViewProps {
  events: CalendarEvent[];
  onSelectEvent?: (event: CalendarEvent) => void;
}

/** Map category name to an Enterprise color dot */
function getCategoryColor(name?: string | null): string {
  if (!name) return "bg-slate-400";
  const n = name.toLowerCase();
  
  // High Priority / Academics
  if (n.includes("exam") || n.includes("test")) return "bg-red-500";
  // Projects / Tech
  if (n.includes("project") || n.includes("web") || n.includes("presentation")) return "bg-blue-600";
  // Extracurriculars
  if (n.includes("cricket") || n.includes("sport")) return "bg-green-500";
  
  return "bg-slate-400";
}

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

const CalendarView = ({ events, onSelectEvent }: CalendarViewProps) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState<Date | null>(null);

  // Build the grid of days for the current month view
  const calendarDays = useMemo(() => {
    const monthStart = startOfMonth(currentMonth);
    const monthEnd = endOfMonth(currentMonth);
    const calStart = startOfWeek(monthStart);
    const calEnd = endOfWeek(monthEnd);
    return eachDayOfInterval({ start: calStart, end: calEnd });
  }, [currentMonth]);

  // Group events by date string for quick lookup
  const eventsByDate = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    for (const event of events) {
      const key = format(new Date(event.event_date), "yyyy-MM-dd");
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(event);
    }
    return map;
  }, [events]);

  // Events for the selected day
  const selectedDayEvents = selectedDay
    ? eventsByDate.get(format(selectedDay, "yyyy-MM-dd")) || []
    : [];

  return (
    <div className="space-y-6 font-sans">
      
      {/* Month Navigation Header */}
      <div className="flex items-center justify-between px-2">
        <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
          <CalendarIcon className="w-5 h-5 text-slate-400" />
          {format(currentMonth, "MMMM yyyy")}
        </h2>
        <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-md shadow-sm p-0.5">
          <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-600 hover:text-slate-900 hover:bg-slate-100" onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="w-px h-4 bg-slate-200" />
          <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-600 hover:text-slate-900 hover:bg-slate-100" onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Calendar Grid Section */}
      <div>
        {/* Weekday headers */}
        <div className="grid grid-cols-7 mb-2">
          {WEEKDAYS.map((day) => (
            <div key={day} className="text-center text-[11px] font-bold text-slate-500 uppercase tracking-wider py-1">
              {day}
            </div>
          ))}
        </div>

        {/* The Grid - Uses a clever 1px gap on a dark background to create perfectly crisp borders */}
        <div className="grid grid-cols-7 gap-px rounded-xl border border-slate-200 bg-slate-200 overflow-hidden shadow-sm">
          {calendarDays.map((day) => {
            const dateKey = format(day, "yyyy-MM-dd");
            const dayEvents = eventsByDate.get(dateKey) || [];
            const inMonth = isSameMonth(day, currentMonth);
            const today = isToday(day);
            const selected = selectedDay && isSameDay(day, selectedDay);

            return (
              <button
                key={dateKey}
                onClick={() => setSelectedDay(day)}
                className={`
                  min-h-[80px] sm:min-h-[100px] p-2 text-left transition-colors relative
                  focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500
                  ${inMonth ? "bg-white hover:bg-slate-50" : "bg-slate-50/50 hover:bg-slate-100/50 text-slate-400"}
                  ${selected ? "ring-2 ring-inset ring-slate-900 bg-slate-50" : ""}
                `}
              >
                {/* Date Number */}
                <span
                  className={`
                    text-xs font-bold inline-flex items-center justify-center w-6 h-6 rounded-md mb-1
                    ${today ? "bg-blue-600 text-white shadow-sm" : inMonth ? "text-slate-900" : "text-slate-400"}
                  `}
                >
                  {format(day, "d")}
                </span>
                
                {/* Event Mini-Previews */}
                <div className="space-y-1">
                  {dayEvents.slice(0, 3).map((evt) => (
                    <div
                      key={evt.id}
                      className={`flex items-center gap-1.5 px-1.5 py-0.5 rounded text-[10px] font-medium truncate border
                        ${inMonth ? 'bg-slate-50 border-slate-100 text-slate-700' : 'bg-transparent border-transparent text-slate-400'}
                      `}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${getCategoryColor(evt.categories?.name)}`} />
                      <span className="truncate">{evt.title}</span>
                    </div>
                  ))}
                  {dayEvents.length > 3 && (
                    <div className="text-[10px] font-semibold text-slate-500 pl-1 pt-0.5">
                      +{dayEvents.length - 3} more
                    </div>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Day Detail Panel */}
      {selectedDay && (
        <div className="rounded-xl border border-slate-200 bg-white shadow-sm p-5 animate-in slide-in-from-bottom-2 fade-in duration-200">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
            <h3 className="text-base font-bold text-slate-900">
              {format(selectedDay, "EEEE, MMMM d, yyyy")}
            </h3>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider bg-slate-100 px-2 py-1 rounded-md">
              {selectedDayEvents.length} {selectedDayEvents.length === 1 ? 'Event' : 'Events'}
            </span>
          </div>
          
          {selectedDayEvents.length === 0 ? (
            <p className="text-sm text-slate-500 italic py-4 text-center">Your schedule is clear for this day.</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {selectedDayEvents.map((evt) => (
                <button
                  key={evt.id}
                  onClick={() => onSelectEvent?.(evt)}
                  className="w-full flex items-start gap-3 rounded-lg border border-slate-200 p-3 text-left hover:border-slate-300 hover:shadow-sm transition-all group bg-white"
                >
                  <div className={`mt-1 w-2.5 h-2.5 rounded-full shrink-0 ${getCategoryColor(evt.categories?.name)}`} />
                  <div className="min-w-0 flex-1">
                    <p className="font-bold text-sm text-slate-900 truncate group-hover:text-blue-600 transition-colors">{evt.title}</p>
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className="flex items-center gap-1 text-[11px] font-medium text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                        <Clock className="w-3 h-3" />
                        {format(new Date(evt.event_date), "h:mm a")}
                      </span>
                      {evt.categories?.name && (
                        <span className="text-[11px] font-medium text-slate-500 truncate">
                          • {evt.categories.name}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default CalendarView;