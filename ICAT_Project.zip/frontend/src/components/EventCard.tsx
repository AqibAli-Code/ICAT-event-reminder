/**
 * EventCard - Enterprise Edition with Call Reminder Support
 */

import { format, isPast, isToday } from "date-fns";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Pencil, Trash2, Clock, AlignLeft, Phone } from "lucide-react";

interface EventCardProps {
  event: {
    id: string;
    title: string;
    description?: string | null;
    event_date: string;
    category_id?: string | null;
    is_alarm_dismissed: boolean;
    categories?: { name: string } | null;
  };
  onEdit: () => void;
  onDelete: () => void;
}

export default function EventCard({ event, onEdit, onDelete }: EventCardProps) {
  const eventDate = new Date(event.event_date);
  const past = isPast(eventDate);
  const today = isToday(eventDate);

 
  // Smart Detection: Is this a call reminder?
  const categoryName = event.categories?.name || "";
  const eventTitle = event.title || "";
  const isCallReminder = categoryName.toLowerCase().includes("call") || eventTitle.toLowerCase().includes("call");

  const getCategoryColor = (name?: string | null) => {
    if (!name) return "bg-slate-400";
    const n = name.toLowerCase();
    if (n.includes("exam") || n.includes("test")) return "bg-red-500";
    if (n.includes("project") || n.includes("web") || n.includes("presentation")) return "bg-blue-600";
    if (n.includes("cricket") || n.includes("sport")) return "bg-green-500";
    if (n.includes("call") || n.includes("meeting")) return "bg-emerald-500";
    return "bg-slate-400";
  };

  return (
    <Card 
      className={`group relative bg-white border border-slate-200 shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden flex flex-col sm:flex-row items-stretch
        ${past && !today ? 'opacity-75 bg-slate-50/50' : ''}
      `}
    >
      {/* Dynamic Left Accent Bar (Green for Calls, Blue for Today, Gray otherwise) */}
      <div className={`w-1.5 shrink-0 
        ${isCallReminder && !past ? 'bg-emerald-500' : today && !past ? 'bg-blue-600' : 'bg-slate-200'}
      `} />

      <div className="flex-1 p-4 sm:p-5 flex flex-col sm:flex-row gap-4 sm:gap-6 items-start sm:items-center">

        <div className="flex flex-col items-center justify-center min-w-[64px] shrink-0 bg-white rounded-lg p-2 border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-0.5">
            {format(eventDate, "MMM")}
          </span>
          <span className={`text-2xl font-black tracking-tight leading-none 
            ${isCallReminder && !past ? 'text-emerald-600' : today && !past ? 'text-blue-600' : 'text-slate-900'}
          `}>
            {format(eventDate, "dd")}
          </span>
        </div>

        <div className="flex-1 min-w-0 space-y-1.5">
          <div className="flex items-center gap-2">
            <h3 className={`text-base font-bold truncate ${past && !today ? 'text-slate-500 line-through' : 'text-slate-900'}`}>
              {event.title}
            </h3>
            {today && !event.is_alarm_dismissed && (
              <Badge className={`${isCallReminder ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-blue-50 text-blue-700 border-blue-200'} border text-[10px] uppercase px-2 py-0 h-5 font-bold shadow-none rounded-sm`}>
                Today
              </Badge>
            )}
          </div>

          {event.description && (
            <p className="text-sm text-slate-600 truncate flex items-center gap-1.5">
              {isCallReminder ? <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" /> : <AlignLeft className="w-3.5 h-3.5 text-slate-400 shrink-0" />}
              {event.description}
            </p>
          )}

          <div className="flex flex-wrap items-center gap-3 pt-1 text-xs font-medium text-slate-600">
            <span className="flex items-center gap-1.5 bg-slate-100 border border-slate-200 px-2.5 py-1 rounded-md text-slate-700">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              {format(eventDate, "h:mm a")}
            </span>
            {event.categories?.name && (
              <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-slate-200 bg-white text-slate-700 shadow-sm">
                <span className={`w-2 h-2 rounded-full shadow-inner ${getCategoryColor(event.categories.name)}`} />
                {event.categories.name}
              </span>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex sm:flex-col gap-2 w-full sm:w-auto mt-3 sm:mt-0 shrink-0">
          
          {/* NEW: Dedicated Call Button */}
          {isCallReminder && !past && (
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1 sm:flex-none h-8 px-3 text-emerald-700 hover:text-emerald-800 hover:bg-emerald-50 border-emerald-200 shadow-sm transition-colors" 
              onClick={() => window.open(`tel:${event.description?.replace(/[^0-9+]/g, '') || ''}`)}
            >
              <Phone className="w-3.5 h-3.5 sm:mr-0 mr-2" />
              <span className="sm:hidden font-semibold">Call Now</span>
            </Button>
          )}

          <div className="flex gap-2 w-full sm:w-auto">
            <Button variant="outline" size="sm" className="flex-1 sm:flex-none h-8 px-3 text-slate-600 hover:text-slate-900 hover:bg-slate-100 border-slate-200 shadow-sm" onClick={onEdit}>
              <Pencil className="w-3.5 h-3.5 sm:mr-0 mr-2" />
              <span className="sm:hidden font-semibold">Edit</span>
            </Button>
            <Button variant="outline" size="sm" className="flex-1 sm:flex-none h-8 px-3 text-red-600 hover:text-red-700 hover:bg-red-50 border-slate-200 shadow-sm" onClick={onDelete}>
              <Trash2 className="w-3.5 h-3.5 sm:mr-0 mr-2" />
              <span className="sm:hidden font-semibold">Delete</span>
            </Button>
          </div>
        </div>

      </div>
    </Card>
  );
}