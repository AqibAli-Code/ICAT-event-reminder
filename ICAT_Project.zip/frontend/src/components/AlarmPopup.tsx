/**
 * AlarmPopup - Enterprise Edition with HTML5 Audio for Mobile Support
 */

import { useEffect, useRef, useState } from "react";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BellRing, Clock, Moon, CheckCircle, PhoneCall } from "lucide-react";

interface AlarmPopupProps {
  open: boolean;
  event: any;
  alarmSoundUrl: string | null;
  onDismiss: () => void;
  onSnooze: (minutes: number) => void;
}

const AlarmPopup = ({ open, event, alarmSoundUrl, onDismiss, onSnooze }: AlarmPopupProps) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [snoozeTime, setSnoozeTime] = useState<string>("5");

  // Pointing to the local file in your public folder! Edge cannot block this!
  const soundSource = "/alarm.ogg";

  useEffect(() => {
    // When the popup opens, tell the HTML5 audio tag to play
    if (open && event && audioRef.current) {
      // Small timeout helps bypass some mobile rendering blocks
      setTimeout(() => {
        if (audioRef.current) {
          audioRef.current.play().catch(e => console.error("Mobile blocked audio:", e));
        }
      }, 100);
    } else if (!open && audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  }, [open, event]);

  if (!event) return null;

  const eventDate = new Date(event.event_date);
  
  const categoryName = event.categories?.name || "";
  const eventTitle = event.title || "";
  const isCallReminder = categoryName.toLowerCase().includes("call") || eventTitle.toLowerCase().includes("call");

  return (
    <Dialog open={open} onOpenChange={(isOpen) => { if (!isOpen) onDismiss(); }}>
      <DialogContent 
        className="sm:max-w-[400px] p-0 overflow-hidden border-0 shadow-2xl rounded-xl font-sans"
        onInteractOutside={(e) => e.preventDefault()}
        hideCloseButton
      >
        {/* PHYSICAL HTML5 AUDIO TAG FOR MOBILE BROWSERS - HIDDEN VIA CSS TRICK */}
        <audio ref={audioRef} src={soundSource} loop autoPlay preload="auto" className="opacity-0 absolute w-0 h-0 pointer-events-none" />
        
        <div className={`${isCallReminder ? 'bg-emerald-500' : 'bg-blue-600'} px-6 py-6 text-center relative overflow-hidden transition-colors`}>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-24 h-24 bg-white/20 rounded-full animate-ping opacity-75" />
          </div>
          
          <div className="relative z-10 flex flex-col items-center">
            <div className="bg-white p-3 rounded-full shadow-lg mb-3">
              {isCallReminder ? (
                <PhoneCall className="w-8 h-8 text-emerald-600 animate-pulse" />
              ) : (
                <BellRing className="w-8 h-8 text-blue-600 animate-pulse" />
              )}
            </div>
            <DialogTitle className="text-2xl font-black text-white tracking-tight">
              {isCallReminder ? "Call Reminder" : "Event Starting"}
            </DialogTitle>
          </div>
        </div>

        <div className="px-6 py-6 bg-white text-center flex flex-col items-center">
          <h3 className="text-xl font-bold text-slate-900 mb-2 truncate w-full px-4">
            {event.title}
          </h3>
          <div className={`flex items-center gap-2 text-sm font-semibold text-slate-500 bg-slate-100 px-3 py-1.5 rounded-md mb-4`}>
            <Clock className={`w-4 h-4 ${isCallReminder ? 'text-emerald-600' : 'text-blue-600'}`} />
            {format(eventDate, "h:mm a")} • {format(eventDate, "MMMM d")}
          </div>
          {event.description && (
            <p className="text-sm text-slate-600 line-clamp-2 px-4 italic">"{event.description}"</p>
          )}
        </div>

        <div className="px-6 py-5 bg-slate-50 border-t border-slate-100 flex flex-col gap-3">
          {isCallReminder && (
            <Button 
              onClick={() => {
                window.open(`tel:${event.description?.replace(/[^0-9+]/g, '') || ''}`);
                onDismiss();
              }} 
              className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold h-12 text-base shadow-sm"
            >
              <PhoneCall className="w-5 h-5 mr-2" />
              Call Now
            </Button>
          )}

          <Button onClick={onDismiss} className={`w-full ${isCallReminder ? 'bg-slate-900' : 'bg-slate-900'} hover:bg-slate-800 text-white font-bold h-12 text-base shadow-sm`}>
            <CheckCircle className="w-5 h-5 mr-2" />
            Dismiss Alarm
          </Button>

          <div className="flex items-center gap-2 mt-1">
            <Select value={snoozeTime} onValueChange={setSnoozeTime}>
              <SelectTrigger className="w-[120px] bg-white border-slate-300 h-10 font-medium"><SelectValue placeholder="Time" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="5">5 minutes</SelectItem>
                <SelectItem value="10">10 minutes</SelectItem>
                <SelectItem value="15">15 minutes</SelectItem>
                <SelectItem value="30">30 minutes</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={() => onSnooze(parseInt(snoozeTime))} className="flex-1 bg-white border-slate-300 text-slate-700 hover:bg-slate-100 font-semibold h-10">
              <Moon className="w-4 h-4 mr-2 text-slate-500" />
              Snooze
            </Button>
          </div>
        </div>

      </DialogContent>
    </Dialog>
  );
};

export default AlarmPopup;