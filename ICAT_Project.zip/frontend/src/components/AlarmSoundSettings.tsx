/**
 * AlarmSoundSettings - Lets users pick a preset alarm tone or upload their own sound file.
 * Saves the preference to the user's profile.
 */

import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Volume2, Upload, Trash2, Play } from "lucide-react";
import { playPresetTone, PRESET_TONES } from "@/lib/alarm-sounds";

const AlarmSoundSettings = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedSound, setSelectedSound] = useState("preset:classic");
  const [customSoundUrl, setCustomSoundUrl] = useState<string | null>(null);
  const [customSoundName, setCustomSoundName] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Load current preference
  useEffect(() => {
    if (!user) return;
    supabase
      .from("profiles")
      .select("alarm_sound_url")
      .eq("user_id", user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (data?.alarm_sound_url) {
          setSelectedSound(data.alarm_sound_url);
          if (!data.alarm_sound_url.startsWith("preset:")) {
            setCustomSoundUrl(data.alarm_sound_url);
            setCustomSoundName("Custom sound");
          }
        }
      });
  }, [user]);

  // Preview a preset tone
  const handlePreview = (presetKey: string) => {
    stopPreview();
    if (presetKey.startsWith("preset:")) {
      const toneName = presetKey.replace("preset:", "");
      playPresetTone(toneName);
    } else {
      // Play custom uploaded sound
      const audio = new Audio(presetKey);
      audio.play();
      audioRef.current = audio;
    }
  };

  const stopPreview = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
  };

  // Upload a custom alarm sound
  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    // Validate file type
    const validTypes = ["audio/mpeg", "audio/wav", "audio/ogg", "audio/mp3", "audio/x-wav"];
    if (!validTypes.includes(file.type)) {
      toast({ title: "Invalid file type", description: "Please upload an MP3, WAV, or OGG file.", variant: "destructive" });
      return;
    }

    // Max 5MB
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "File too large", description: "Maximum file size is 5MB.", variant: "destructive" });
      return;
    }

    setUploading(true);
    try {
      const filePath = `${user.id}/${Date.now()}-${file.name}`;
      const { error: uploadError } = await supabase.storage
        .from("alarm-sounds")
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from("alarm-sounds")
        .getPublicUrl(filePath);

      const publicUrl = urlData.publicUrl;
      setCustomSoundUrl(publicUrl);
      setCustomSoundName(file.name);
      setSelectedSound(publicUrl);
      toast({ title: "Sound uploaded successfully!" });
    } catch (err: any) {
      toast({ title: "Upload failed", description: err.message, variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  // Remove custom sound
  const handleRemoveCustom = async () => {
    setCustomSoundUrl(null);
    setCustomSoundName(null);
    if (!selectedSound.startsWith("preset:")) {
      setSelectedSound("preset:classic");
    }
  };

  // Save preference to profile
  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({ alarm_sound_url: selectedSound })
      .eq("user_id", user.id);

    if (error) {
      toast({ title: "Error saving", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Alarm sound saved!" });
    }
    setSaving(false);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Volume2 className="h-5 w-5" />
          Alarm Sound
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Preset tones */}
        <RadioGroup value={selectedSound} onValueChange={setSelectedSound} className="space-y-2">
          {PRESET_TONES.map((tone) => (
            <div key={tone.key} className="flex items-center justify-between rounded-lg border p-3">
              <div className="flex items-center gap-3">
                <RadioGroupItem value={`preset:${tone.key}`} id={`tone-${tone.key}`} />
                <Label htmlFor={`tone-${tone.key}`} className="cursor-pointer">
                  <span className="font-medium text-foreground">{tone.name}</span>
                  <span className="block text-xs text-muted-foreground">{tone.description}</span>
                </Label>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => handlePreview(`preset:${tone.key}`)}
              >
                <Play className="h-4 w-4" />
              </Button>
            </div>
          ))}

          {/* Custom uploaded sound option */}
          {customSoundUrl && (
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div className="flex items-center gap-3">
                <RadioGroupItem value={customSoundUrl} id="tone-custom" />
                <Label htmlFor="tone-custom" className="cursor-pointer">
                  <span className="font-medium text-foreground">Custom Sound</span>
                  <span className="block text-xs text-muted-foreground">{customSoundName}</span>
                </Label>
              </div>
              <div className="flex gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => handlePreview(customSoundUrl)}
                >
                  <Play className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-destructive"
                  onClick={handleRemoveCustom}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </RadioGroup>

        {/* Upload custom sound */}
        <div className="flex items-center gap-2">
          <Label
            htmlFor="alarm-upload"
            className="flex items-center gap-2 cursor-pointer rounded-md border border-dashed px-4 py-2 text-sm text-muted-foreground hover:bg-muted transition-colors"
          >
            <Upload className="h-4 w-4" />
            {uploading ? "Uploading..." : "Upload custom sound"}
          </Label>
          <Input
            id="alarm-upload"
            type="file"
            accept="audio/mpeg,audio/wav,audio/ogg,.mp3,.wav,.ogg"
            className="hidden"
            onChange={handleUpload}
            disabled={uploading}
          />
          <span className="text-xs text-muted-foreground">MP3, WAV, or OGG (max 5MB)</span>
        </div>

        <Button onClick={handleSave} disabled={saving} className="w-full">
          {saving ? "Saving..." : "Save Alarm Sound"}
        </Button>
      </CardContent>
    </Card>
  );
};

export default AlarmSoundSettings;
