/**
 * StreakTracker - Shows consecutive days with dismissed (completed) events.
 */

import { useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Flame, Trophy } from "lucide-react";

interface StreakTrackerProps {
  events: Array<{
    event_date: string;
    is_alarm_dismissed: boolean;
  }>;
}

const StreakTracker = ({ events }: StreakTrackerProps) => {
  const { currentStreak, bestStreak } = useMemo(() => {
    // Get unique days where user dismissed alarms (completed events on time)
    const completedDays = new Set<string>();
    for (const event of events) {
      if (event.is_alarm_dismissed) {
        const day = new Date(event.event_date).toISOString().split("T")[0];
        completedDays.add(day);
      }
    }

    if (completedDays.size === 0) return { currentStreak: 0, bestStreak: 0 };

    // Sort days
    const sortedDays = Array.from(completedDays).sort();

    // Calculate streaks
    let best = 1;
    let current = 1;
    for (let i = 1; i < sortedDays.length; i++) {
      const prev = new Date(sortedDays[i - 1]);
      const curr = new Date(sortedDays[i]);
      const diffMs = curr.getTime() - prev.getTime();
      const diffDays = diffMs / (1000 * 60 * 60 * 24);

      if (diffDays === 1) {
        current++;
        best = Math.max(best, current);
      } else {
        current = 1;
      }
    }

    // Check if current streak is still active (last completed day is today or yesterday)
    const today = new Date().toISOString().split("T")[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split("T")[0];
    const lastDay = sortedDays[sortedDays.length - 1];
    const isActive = lastDay === today || lastDay === yesterday;

    return {
      currentStreak: isActive ? current : 0,
      bestStreak: best,
    };
  }, [events]);

  return (
    <div className="grid grid-cols-2 gap-3">
      <Card className="border-orange-500/20 bg-orange-500/5">
        <CardContent className="p-4 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-orange-500/10">
            <Flame className="h-5 w-5 text-orange-500" />
          </div>
          <div>
            <p className="text-2xl font-bold text-foreground">{currentStreak}</p>
            <p className="text-xs text-muted-foreground">Day Streak</p>
          </div>
        </CardContent>
      </Card>
      <Card className="border-yellow-500/20 bg-yellow-500/5">
        <CardContent className="p-4 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-yellow-500/10">
            <Trophy className="h-5 w-5 text-yellow-500" />
          </div>
          <div>
            <p className="text-2xl font-bold text-foreground">{bestStreak}</p>
            <p className="text-xs text-muted-foreground">Best Streak</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StreakTracker;
