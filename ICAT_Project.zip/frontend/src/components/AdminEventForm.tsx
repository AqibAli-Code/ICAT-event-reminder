/**
 * AdminEventForm - Admin form to create events for multiple users.
 * Uses "Select all + exclude" pattern for user selection.
 */

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { fetchCategories, fetchAllProfiles } from "@/lib/supabase-helpers";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Users, X } from "lucide-react";

interface Category {
  id: string;
  name: string;
}

interface Profile {
  id: string;
  user_id: string;
  full_name: string | null;
}

interface AdminEventFormProps {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
}

const AdminEventForm = ({ open, onClose, onSaved }: AdminEventFormProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [categories, setCategories] = useState<Category[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [eventDate, setEventDate] = useState("");
  const [eventTime, setEventTime] = useState("");
  const [categoryId, setCategoryId] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [allSelected, setAllSelected] = useState(true);
  const [excludedUsers, setExcludedUsers] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!open) return;
    Promise.all([fetchCategories(), fetchAllProfiles()]).then(([catsRes, profilesRes]) => {
      if (catsRes.data) setCategories(catsRes.data);
      if (profilesRes.data) setProfiles(profilesRes.data);
    });
    // Reset form
    setTitle("");
    setDescription("");
    setEventDate("");
    setEventTime("");
    setCategoryId("");
    setAllSelected(true);
    setExcludedUsers(new Set());
  }, [open]);

  const selectedUsers = profiles.filter((p) => allSelected ? !excludedUsers.has(p.user_id) : false);
  const selectedCount = selectedUsers.length;

  const toggleUser = (userId: string) => {
    setExcludedUsers((prev) => {
      const next = new Set(prev);
      if (next.has(userId)) {
        next.delete(userId);
      } else {
        next.add(userId);
      }
      return next;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || selectedCount === 0) return;
    setLoading(true);

    const eventDatetime = new Date(`${eventDate}T${eventTime}`).toISOString();
    const targetUserIds = selectedUsers.map((p) => p.user_id);

    try {
      // Create the event owned by admin
      const { data: eventData, error: eventError } = await supabase
        .from("events")
        .insert({
          title: title.trim(),
          description: description.trim() || null,
          event_date: eventDatetime,
          category_id: categoryId || null,
          user_id: user.id,
          created_by: user.id,
        })
        .select()
        .single();

      if (eventError) throw eventError;

      // Create event_users entries for all selected users
      const eventUserRows = targetUserIds.map((uid) => ({
        event_id: eventData.id,
        user_id: uid,
      }));

      const { error: assignError } = await supabase
        .from("event_users")
        .insert(eventUserRows);

      if (assignError) throw assignError;

      toast({ title: `Event created for ${selectedCount} user(s)!` });
      onSaved();
      onClose();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose} modal={false}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Create Event for Users
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="admin-title">Title *</Label>
            <Input
              id="admin-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Event title"
              required
              maxLength={100}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="admin-category">Category</Label>
            <Select value={categoryId} onValueChange={setCategoryId}>
              <SelectTrigger>
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="admin-date">Date *</Label>
              <Input
                id="admin-date"
                type="date"
                value={eventDate}
                onChange={(e) => setEventDate(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="admin-time">Time *</Label>
              <Input
                id="admin-time"
                type="time"
                value={eventTime}
                onChange={(e) => setEventTime(e.target.value)}
                required
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="admin-description">Description (optional)</Label>
            <Textarea
              id="admin-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add details..."
              maxLength={500}
              rows={2}
            />
          </div>

          {/* User selection - select all + exclude */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Assign to Users</Label>
              <Badge variant="secondary">{selectedCount} selected</Badge>
            </div>
            <div className="flex items-center gap-2 mb-2">
              <Checkbox
                id="select-all"
                checked={allSelected && excludedUsers.size === 0}
                onCheckedChange={(checked) => {
                  setAllSelected(!!checked);
                  setExcludedUsers(new Set());
                }}
              />
              <Label htmlFor="select-all" className="text-sm font-normal cursor-pointer">
                Select All Users
              </Label>
            </div>
            <ScrollArea className="h-40 rounded-md border p-2">
              {profiles.map((profile) => {
                const isSelected = allSelected && !excludedUsers.has(profile.user_id);
                return (
                  <div
                    key={profile.user_id}
                    className="flex items-center gap-2 py-1.5 px-1 hover:bg-muted/50 rounded"
                  >
                    <Checkbox
                      checked={isSelected}
                      onCheckedChange={() => toggleUser(profile.user_id)}
                    />
                    <span className="text-sm text-foreground">
                      {profile.full_name || "Unnamed User"}
                    </span>
                    {excludedUsers.has(profile.user_id) && (
                      <Badge variant="outline" className="text-xs ml-auto">
                        <X className="h-3 w-3 mr-0.5" />
                        Excluded
                      </Badge>
                    )}
                  </div>
                );
              })}
            </ScrollArea>
          </div>

          <div className="flex gap-2 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading || selectedCount === 0}>
              {loading ? "Creating..." : `Create for ${selectedCount} User(s)`}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AdminEventForm;
