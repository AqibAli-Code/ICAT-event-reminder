/**
 * Alarm sound presets - generates different alarm tones using Web Audio API.
 * Also provides a helper to play custom uploaded sounds.
 */

/** Preset tone definitions */
export const PRESET_TONES = [
  { key: "classic", name: "Classic Beep", description: "Standard repeating beep" },
  { key: "gentle", name: "Gentle Chime", description: "Soft, pleasant chime" },
  { key: "urgent", name: "Urgent Alert", description: "Fast, attention-grabbing beeps" },
  { key: "melody", name: "Melody", description: "Short melodic sequence" },
] as const;

export type PresetToneKey = (typeof PRESET_TONES)[number]["key"];

/**
 * Create a repeating alarm sound controller.
 * Supports preset tones and custom audio URLs.
 */
export function createAlarmController(soundUrl: string | null): {
  start: () => void;
  stop: () => void;
} {
  // If it's a custom URL (not a preset), play it as an audio file
  if (soundUrl && !soundUrl.startsWith("preset:")) {
    let audio: HTMLAudioElement | null = null;
    let intervalId: ReturnType<typeof setInterval> | null = null;

    return {
      start: () => {
        const play = () => {
          audio = new Audio(soundUrl);
          audio.volume = 0.7;
          audio.play().catch(() => {});
        };
        play();
        intervalId = setInterval(play, 4000);
      },
      stop: () => {
        if (intervalId) clearInterval(intervalId);
        if (audio) {
          audio.pause();
          audio = null;
        }
      },
    };
  }

  // Otherwise use Web Audio API for preset tones
  const toneKey = soundUrl?.replace("preset:", "") || "classic";
  let audioCtx: AudioContext | null = null;
  let intervalId: ReturnType<typeof setInterval> | null = null;

  return {
    start: () => {
      try {
        audioCtx = new AudioContext();
        const playTone = () => {
          if (!audioCtx) return;
          switch (toneKey) {
            case "gentle":
              playGentleChime(audioCtx);
              break;
            case "urgent":
              playUrgentAlert(audioCtx);
              break;
            case "melody":
              playMelody(audioCtx);
              break;
            default:
              playClassicBeep(audioCtx);
          }
        };
        playTone();
        const interval = toneKey === "urgent" ? 1000 : toneKey === "melody" ? 3000 : 1500;
        intervalId = setInterval(playTone, interval);
      } catch (e) {
        console.warn("Audio not available:", e);
      }
    },
    stop: () => {
      if (intervalId) clearInterval(intervalId);
      if (audioCtx) {
        audioCtx.close();
        audioCtx = null;
      }
    },
  };
}

/** Play a preset tone for preview (plays once) */
export function playPresetTone(toneKey: string) {
  try {
    const ctx = new AudioContext();
    switch (toneKey) {
      case "gentle":
        playGentleChime(ctx);
        break;
      case "urgent":
        playUrgentAlert(ctx);
        break;
      case "melody":
        playMelody(ctx);
        break;
      default:
        playClassicBeep(ctx);
    }
    // Close context after tone finishes
    setTimeout(() => ctx.close(), 2000);
  } catch (e) {
    console.warn("Audio not available:", e);
  }
}

// ---- Tone generators ----

function playClassicBeep(ctx: AudioContext) {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.frequency.value = 800;
  osc.type = "sine";
  gain.gain.setValueAtTime(0.3, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
  osc.start(ctx.currentTime);
  osc.stop(ctx.currentTime + 0.5);
}

function playGentleChime(ctx: AudioContext) {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.frequency.value = 523; // C5
  osc.type = "triangle";
  gain.gain.setValueAtTime(0.2, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 1.0);
  osc.start(ctx.currentTime);
  osc.stop(ctx.currentTime + 1.0);

  // Second chime note
  const osc2 = ctx.createOscillator();
  const gain2 = ctx.createGain();
  osc2.connect(gain2);
  gain2.connect(ctx.destination);
  osc2.frequency.value = 659; // E5
  osc2.type = "triangle";
  gain2.gain.setValueAtTime(0, ctx.currentTime + 0.3);
  gain2.gain.linearRampToValueAtTime(0.2, ctx.currentTime + 0.35);
  gain2.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 1.2);
  osc2.start(ctx.currentTime + 0.3);
  osc2.stop(ctx.currentTime + 1.2);
}

function playUrgentAlert(ctx: AudioContext) {
  for (let i = 0; i < 3; i++) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = 1000;
    osc.type = "square";
    const start = ctx.currentTime + i * 0.2;
    gain.gain.setValueAtTime(0.15, start);
    gain.gain.exponentialRampToValueAtTime(0.01, start + 0.12);
    osc.start(start);
    osc.stop(start + 0.12);
  }
}

function playMelody(ctx: AudioContext) {
  const notes = [523, 587, 659, 784]; // C5, D5, E5, G5
  notes.forEach((freq, i) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = freq;
    osc.type = "sine";
    const start = ctx.currentTime + i * 0.25;
    gain.gain.setValueAtTime(0.25, start);
    gain.gain.exponentialRampToValueAtTime(0.01, start + 0.4);
    osc.start(start);
    osc.stop(start + 0.4);
  });
}
