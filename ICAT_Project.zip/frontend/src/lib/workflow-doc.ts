/**
 * Workflow Document Generator
 * Generates and downloads a PDF-based system workflow summary.
 */

import jsPDF from "jspdf";

export function generateWorkflowDocument() {
  const doc = new jsPDF();
  let y = 20;
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 20;
  const contentWidth = pageWidth - margin * 2;

  const addPage = () => {
    doc.addPage();
    y = 20;
  };

  const checkPage = (needed: number) => {
    if (y + needed > 270) addPage();
  };

  const title = (text: string) => {
    checkPage(20);
    doc.setFontSize(18);
    doc.setFont("helvetica", "bold");
    doc.text(text, pageWidth / 2, y, { align: "center" });
    y += 10;
  };

  const heading = (text: string) => {
    checkPage(16);
    y += 4;
    doc.setFontSize(13);
    doc.setFont("helvetica", "bold");
    doc.text(text, margin, y);
    y += 2;
    doc.setLineWidth(0.5);
    doc.line(margin, y, pageWidth - margin, y);
    y += 7;
  };

  const body = (text: string) => {
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    const lines = doc.splitTextToSize(text, contentWidth);
    for (const line of lines) {
      checkPage(6);
      doc.text(line, margin, y);
      y += 5;
    }
  };

  const bullet = (text: string, indent = 0) => {
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    const x = margin + 4 + indent;
    const lines = doc.splitTextToSize(text, contentWidth - 4 - indent);
    for (let i = 0; i < lines.length; i++) {
      checkPage(6);
      if (i === 0) {
        doc.text("•", margin + indent, y);
      }
      doc.text(lines[i], x + 2, y);
      y += 5;
    }
  };

  const mono = (lines: string[]) => {
    doc.setFontSize(8);
    doc.setFont("courier", "normal");
    for (const line of lines) {
      checkPage(5);
      doc.text(line, margin + 4, y);
      y += 4;
    }
    y += 2;
  };

  // ===== COVER =====
  y = 80;
  doc.setFontSize(24);
  doc.setFont("helvetica", "bold");
  doc.text("STUDENT EVENT REMINDER SYSTEM", pageWidth / 2, y, { align: "center" });
  y += 12;
  doc.setFontSize(14);
  doc.setFont("helvetica", "normal");
  doc.text("Workflow Documentation", pageWidth / 2, y, { align: "center" });
  y += 20;
  doc.setFontSize(10);
  doc.text(`Generated: ${new Date().toLocaleDateString()}`, pageWidth / 2, y, { align: "center" });

  // ===== TABLE OF CONTENTS =====
  addPage();
  doc.setFontSize(16);
  doc.setFont("helvetica", "bold");
  doc.text("Table of Contents", margin, y);
  y += 12;

  const tocItems = [
    { num: "1", title: "System Overview", page: "3" },
    { num: "2", title: "Event Creation Process", page: "3" },
    { num: "3", title: "Reminder / Alarm Triggering Logic", page: "3" },
    { num: "4", title: "Admin Workflow & Controls", page: "4" },
    { num: "5", title: "ER Diagram (Entity Relationship)", page: "5" },
    { num: "6", title: "Class Diagram (Simplified)", page: "5" },
    { num: "7", title: "Technology Stack", page: "6" },
  ];

  doc.setFontSize(11);
  doc.setFont("helvetica", "normal");
  for (const item of tocItems) {
    const label = `${item.num}. ${item.title}`;
    const dots = " . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .";
    doc.text(label, margin + 4, y);
    const labelWidth = doc.getTextWidth(label);
    const pageNumWidth = doc.getTextWidth(item.page);
    const dotsX = margin + 4 + labelWidth;
    const dotsAvail = contentWidth - labelWidth - pageNumWidth - 4;
    const clippedDots = doc.splitTextToSize(dots, dotsAvail)[0] || "";
    doc.setTextColor(150, 150, 150);
    doc.text(clippedDots, dotsX, y);
    doc.setTextColor(0, 0, 0);
    doc.text(item.page, pageWidth - margin, y, { align: "right" });
    y += 8;
  }

  // ===== PAGE 3: OVERVIEW =====
  addPage();

  heading("1. SYSTEM OVERVIEW");
  body("The Student Event Reminder System is a web application designed to help students create, manage, and receive reminders for academic and personal events. The system consists of two main modules:");
  y += 2;
  bullet("Student Module: Event CRUD operations and alarm-based reminders");
  bullet("Admin Module: System management, category control, user management, and settings");

  heading("2. EVENT CREATION PROCESS");
  bullet("Step 1: Student logs in with email and password");
  bullet("Step 2: Student clicks \"New Event\" button");
  bullet("Step 3: Student fills in the event form:");
  bullet("Title (required)", 8);
  bullet("Date and Time (required)", 8);
  bullet("Category (optional: Assignment, Exam, Meeting, Personal, Other)", 8);
  bullet("Description (optional)", 8);
  bullet("Step 4: Event is saved to the database with the student's user ID");
  bullet("Step 5: Event appears in the student's event list, sorted by date");
  y += 4;
  body("Flow Diagram:");
  mono(["[Login] -> [Dashboard] -> [New Event] -> [Fill Form] -> [Save] -> [Event List]"]);

  heading("3. REMINDER / ALARM TRIGGERING LOGIC");
  bullet("The system checks for due events every 30 seconds");
  bullet("When an event's date/time arrives (within a 60-second window):");
  bullet("An alarm popup appears on screen", 8);
  bullet("An audible sound plays using Web Audio API", 8);
  bullet("The popup displays event details (title, category, time, description)", 8);
  bullet("Student can either:", 8);
  bullet("DISMISS: Marks the alarm as dismissed permanently", 12);
  bullet("SNOOZE: Postpones the alarm by 5 minutes (configurable by admin)", 12);
  y += 4;
  body("Alarm Flow:");
  mono(["[Timer Check] -> [Event Due?] -> [Show Popup + Sound] -> [Dismiss/Snooze]"]);

  heading("4. ADMIN WORKFLOW & CONTROLS");
  body("Admin Login: admin@eventreminder.com / admin123");
  y += 2;
  body("Admin Functions:");
  bullet("System Overview Dashboard — View total events, upcoming events, total registered users");
  bullet("User Management — View, edit, and delete registered users");
  bullet("Category Management — Add, edit, delete event categories");
  bullet("Global Settings — Enable/Disable alarms, set volume (0-100%), configure snooze (1-60 min)");
  bullet("Workflow Documentation — Download this PDF summary");

  // ===== ER DIAGRAM =====
  addPage();

  heading("5. ER DIAGRAM (Entity Relationship)");
  mono([
    "  +----------------+     +----------------+",
    "  |  auth.users     |     |   profiles      |",
    "  |----------------|     |----------------|",
    "  | id (PK)        |---->| user_id (FK)    |",
    "  | email          |     | full_name       |",
    "  | password        |     | alarm_sound_url |",
    "  +----------------+     | created_at      |",
    "         |               +----------------+",
    "         | 1:N",
    "         v",
    "  +----------------+     +----------------+",
    "  |  user_roles     |     |  categories     |",
    "  |----------------|     |----------------|",
    "  | user_id (FK)    |     | id (PK)        |",
    "  | role (enum)     |     | name           |",
    "  +----------------+     | created_at      |",
    "                         +----------------+",
    "         |                     |",
    "         |                     | 1:N",
    "         v                     v",
    "  +------------------------------------+",
    "  |            events                   |",
    "  |------------------------------------|",
    "  | id (PK)                            |",
    "  | user_id (FK -> auth.users)          |",
    "  | title                              |",
    "  | description                        |",
    "  | event_date                         |",
    "  | category_id (FK -> categories)      |",
    "  | is_alarm_dismissed                  |",
    "  | created_at, updated_at             |",
    "  +------------------------------------+",
    "",
    "  +--------------------+",
    "  | global_settings     |",
    "  |--------------------|",
    "  | id (PK)            |",
    "  | key                |",
    "  | value              |",
    "  | updated_at         |",
    "  +--------------------+",
  ]);

  // ===== CLASS DIAGRAM =====
  heading("6. CLASS DIAGRAM (Simplified)");
  mono([
    "  +-------------------+",
    "  |      User          |",
    "  |-------------------|",
    "  | - id: UUID         |",
    "  | - email: string    |",
    "  | - fullName: string |",
    "  |-------------------|",
    "  | + signIn()         |",
    "  | + signUp()         |",
    "  | + signOut()        |",
    "  +-------------------+",
    "         |",
    "         | has many",
    "         v",
    "  +-------------------+     +--------------+",
    "  |     Event          |---->|   Category   |",
    "  |-------------------|     |--------------|",
    "  | - id: UUID         |     | - id: UUID   |",
    "  | - title: string    |     | - name: str  |",
    "  | - description      |     +--------------+",
    "  | - eventDate: Date  |",
    "  | - isAlarmDismissed  |",
    "  |-------------------|",
    "  | + create()         |",
    "  | + update()         |",
    "  | + delete()         |",
    "  | + dismissAlarm()   |",
    "  +-------------------+",
    "",
    "  +-------------------+",
    "  |  AlarmService      |",
    "  |-------------------|",
    "  | + checkAlarms()    |",
    "  | + playSound()      |",
    "  | + snooze(min)      |",
    "  | + dismiss()        |",
    "  +-------------------+",
  ]);

  // ===== TECH STACK =====
  heading("7. TECHNOLOGY STACK");
  bullet("Frontend: React + TypeScript + Tailwind CSS");
  bullet("Backend: Cloud Database (PostgreSQL)");
  bullet("Authentication: Email & Password based");
  bullet("Security: Row Level Security (RLS) policies");
  bullet("Alarm: Web Audio API for sound generation");
  y += 8;
  doc.setFontSize(9);
  doc.setFont("helvetica", "italic");
  doc.text("Generated automatically by the Student Event Reminder System", pageWidth / 2, y, { align: "center" });

  // Save
  doc.save("event-reminder-workflow-summary.pdf");
}
