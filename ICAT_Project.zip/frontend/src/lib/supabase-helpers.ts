/**
 * Helper functions for Supabase operations.
 * Provides typed wrappers for common database queries.
 */

import { supabase } from "@/integrations/supabase/client";

// ---- Auth helpers ----

/** Sign up a new user with email, password, and optional full name */
export async function signUp(email: string, password: string, fullName?: string) {
  return supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: window.location.origin,
      data: { full_name: fullName || "" },
    },
  });
}

/** Sign in with email and password */
export async function signIn(email: string, password: string) {
  return supabase.auth.signInWithPassword({ email, password });
}

/** Sign out the current user */
export async function signOut() {
  return supabase.auth.signOut();
}

/** Get the current session */
export async function getSession() {
  return supabase.auth.getSession();
}

// ---- Role helpers ----

/** Check if the current user has admin role */
export async function isCurrentUserAdmin(): Promise<boolean> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return false;

  const { data } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", user.id)
    .eq("role", "admin")
    .maybeSingle();

  return !!data;
}

// ---- Event helpers ----

export interface EventData {
  id?: string;
  title: string;
  description?: string;
  event_date: string;
  category_id?: string | null;
  user_id?: string;
  is_alarm_dismissed?: boolean;
}

/** Fetch all events for the current user (own + assigned), sorted by date */
export async function fetchUserEvents() {
  // RLS handles filtering: users see own events + events assigned via event_users
  return supabase
    .from("events")
    .select("*, categories(name)")
    .order("event_date", { ascending: true });
}

/** Create a new event */
export async function createEvent(event: Omit<EventData, "id">) {
  return supabase.from("events").insert([event as any]).select().single();
}

/** Update an existing event */
export async function updateEvent(id: string, updates: Partial<EventData>) {
  return supabase.from("events").update(updates).eq("id", id).select().single();
}

/** Delete an event */
export async function deleteEvent(id: string) {
  return supabase.from("events").delete().eq("id", id);
}

/** Dismiss alarm for an event */
export async function dismissAlarm(id: string) {
  return supabase.from("events").update({ is_alarm_dismissed: true }).eq("id", id);
}

// ---- Category helpers ----

/** Fetch all categories */
export async function fetchCategories() {
  return supabase.from("categories").select("*").order("name");
}

/** Create a category (admin only) */
export async function createCategory(name: string) {
  return supabase.from("categories").insert({ name }).select().single();
}

/** Update a category (admin only) */
export async function updateCategory(id: string, name: string) {
  return supabase.from("categories").update({ name }).eq("id", id).select().single();
}

/** Delete a category (admin only) */
export async function deleteCategory(id: string) {
  return supabase.from("categories").delete().eq("id", id);
}

// ---- Settings helpers ----

/** Fetch all global settings */
export async function fetchSettings() {
  return supabase.from("global_settings").select("*");
}

/** Update a global setting (admin only) */
export async function updateSetting(key: string, value: string) {
  return supabase
    .from("global_settings")
    .update({ value })
    .eq("key", key)
    .select()
    .single();
}

// ---- Admin stats helpers ----

/** Fetch all events for admin overview (includes created_by) */
export async function fetchAllEvents() {
  return supabase
    .from("events")
    .select("*, categories(name)")
    .order("event_date", { ascending: true });
}

/** Fetch all users with profiles (admin) */
export async function fetchAllProfiles() {
  return supabase.from("profiles").select("*").order("created_at", { ascending: false });
}

/** Fetch events assigned to current user via event_users table */
export async function fetchAssignedEvents() {
  return supabase
    .from("event_users")
    .select("*, events(*, categories(name))")
    .order("created_at", { ascending: false });
}
