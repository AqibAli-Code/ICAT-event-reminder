/**
 * AdminDashboard - Admin panel with system overview, category management,
 * global settings, and workflow documentation download.
 */

import { useState, useEffect } from "react";
import AppHeader from "@/components/AppHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  fetchAllEvents,
  fetchAllProfiles,
  fetchCategories,
  fetchSettings,
  createCategory,
  updateCategory,
  deleteCategory,
  updateSetting,
} from "@/lib/supabase-helpers";
import { useToast } from "@/hooks/use-toast";
import {
  CalendarDays,
  Users,
  FolderOpen,
  Settings,
  Download,
  Plus,
  Pencil,
  Trash2,
  BarChart3,
  X,
  Check,
} from "lucide-react";
import { generateWorkflowDocument } from "@/lib/workflow-doc";
import UserManagement from "@/components/UserManagement";
import AdminEventsTab from "@/components/AdminEventsTab";

interface Category {
  id: string;
  name: string;
}

interface Setting {
  id: string;
  key: string;
  value: string;
}

const AdminDashboard = () => {
  const { toast } = useToast();
  const [totalEvents, setTotalEvents] = useState(0);
  const [totalUsers, setTotalUsers] = useState(0);
  const [upcomingCount, setUpcomingCount] = useState(0);
  const [categories, setCategories] = useState<Category[]>([]);
  const [settings, setSettings] = useState<Setting[]>([]);
  const [newCategoryName, setNewCategoryName] = useState("");
  const [editingCat, setEditingCat] = useState<string | null>(null);
  const [editCatName, setEditCatName] = useState("");

  // Load all admin data
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [eventsRes, profilesRes, catsRes, settingsRes] = await Promise.all([
      fetchAllEvents(),
      fetchAllProfiles(),
      fetchCategories(),
      fetchSettings(),
    ]);

    if (eventsRes.data) {
      setTotalEvents(eventsRes.data.length);
      setUpcomingCount(
        eventsRes.data.filter((e: any) => new Date(e.event_date) >= new Date()).length
      );
    }
    if (profilesRes.data) setTotalUsers(profilesRes.data.length);
    if (catsRes.data) setCategories(catsRes.data);
    if (settingsRes.data) setSettings(settingsRes.data);
  };

  // Category management
  const handleAddCategory = async () => {
    if (!newCategoryName.trim()) return;
    const { error } = await createCategory(newCategoryName.trim());
    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Category added" });
      setNewCategoryName("");
      loadData();
    }
  };

  const handleUpdateCategory = async (id: string) => {
    if (!editCatName.trim()) return;
    const { error } = await updateCategory(id, editCatName.trim());
    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Category updated" });
      setEditingCat(null);
      loadData();
    }
  };

  const handleDeleteCategory = async (id: string) => {
    const { error } = await deleteCategory(id);
    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Category deleted" });
      loadData();
    }
  };

  // Settings management
  const handleToggleSetting = async (key: string, currentValue: string) => {
    const newValue = currentValue === "true" ? "false" : "true";
    await updateSetting(key, newValue);
    loadData();
  };

  const handleUpdateVolume = async (value: string) => {
    await updateSetting("alarm_sound_volume", value);
    loadData();
  };

  const handleUpdateSnooze = async (value: string) => {
    await updateSetting("snooze_duration_minutes", value);
    loadData();
  };

  const getSetting = (key: string) => settings.find((s) => s.key === key)?.value || "";

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />
      <main className="container py-6 max-w-4xl">
        <h1 className="text-2xl font-bold text-foreground mb-6">Admin Dashboard</h1>

        {/* Stats overview */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <CalendarDays className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{totalEvents}</p>
                <p className="text-xs text-muted-foreground">Total Events</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/10">
                <BarChart3 className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{upcomingCount}</p>
                <p className="text-xs text-muted-foreground">Upcoming</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-info/10">
                <Users className="h-5 w-5 text-info" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{totalUsers}</p>
                <p className="text-xs text-muted-foreground">Registered Users</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs for categories, settings, workflow */}
        <Tabs defaultValue="users">
          <TabsList className="mb-4">
            <TabsTrigger value="users">
              <Users className="h-4 w-4 mr-1" />
              Users
            </TabsTrigger>
            <TabsTrigger value="events">
              <CalendarDays className="h-4 w-4 mr-1" />
              Events
            </TabsTrigger>
            <TabsTrigger value="categories">
              <FolderOpen className="h-4 w-4 mr-1" />
              Categories
            </TabsTrigger>
            <TabsTrigger value="settings">
              <Settings className="h-4 w-4 mr-1" />
              Settings
            </TabsTrigger>
            <TabsTrigger value="workflow">
              <Download className="h-4 w-4 mr-1" />
              Workflow
            </TabsTrigger>
          </TabsList>

          {/* Users tab */}
          <TabsContent value="users">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Registered Users</CardTitle>
              </CardHeader>
              <CardContent>
                <UserManagement />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Events tab */}
          <TabsContent value="events" forceMount className="data-[state=inactive]:hidden">
            <AdminEventsTab />
          </TabsContent>

          {/* Categories tab */}
          <TabsContent value="categories">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Manage Categories</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Add new category */}
                <div className="flex gap-2">
                  <Input
                    placeholder="New category name..."
                    value={newCategoryName}
                    onChange={(e) => setNewCategoryName(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleAddCategory()}
                    maxLength={50}
                  />
                  <Button onClick={handleAddCategory} disabled={!newCategoryName.trim()}>
                    <Plus className="h-4 w-4 mr-1" />
                    Add
                  </Button>
                </div>
                {/* Category list */}
                <div className="space-y-2">
                  {categories.map((cat) => (
                    <div
                      key={cat.id}
                      className="flex items-center justify-between rounded-lg border p-3"
                    >
                      {editingCat === cat.id ? (
                        <div className="flex items-center gap-2 flex-1">
                          <Input
                            value={editCatName}
                            onChange={(e) => setEditCatName(e.target.value)}
                            className="h-8"
                            maxLength={50}
                          />
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8"
                            onClick={() => handleUpdateCategory(cat.id)}
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8"
                            onClick={() => setEditingCat(null)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ) : (
                        <>
                          <span className="font-medium text-foreground">{cat.name}</span>
                          <div className="flex gap-1">
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-8 w-8"
                              onClick={() => {
                                setEditingCat(cat.id);
                                setEditCatName(cat.name);
                              }}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-8 w-8 text-destructive"
                              onClick={() => handleDeleteCategory(cat.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings tab */}
          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Alarm & Reminder Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="font-medium">Enable Alarms</Label>
                    <p className="text-sm text-muted-foreground">
                      Turn alarm sounds on or off globally
                    </p>
                  </div>
                  <Switch
                    checked={getSetting("alarm_enabled") === "true"}
                    onCheckedChange={() =>
                      handleToggleSetting("alarm_enabled", getSetting("alarm_enabled"))
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-medium">Alarm Volume (%)</Label>
                  <Input
                    type="number"
                    min="0"
                    max="100"
                    value={getSetting("alarm_sound_volume")}
                    onChange={(e) => handleUpdateVolume(e.target.value)}
                    className="w-32"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-medium">Snooze Duration (minutes)</Label>
                  <Input
                    type="number"
                    min="1"
                    max="60"
                    value={getSetting("snooze_duration_minutes")}
                    onChange={(e) => handleUpdateSnooze(e.target.value)}
                    className="w-32"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Workflow tab */}
          <TabsContent value="workflow">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">System Workflow Documentation</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Download a summary document that explains the system's workflow including event
                  creation process, reminder triggering logic, admin controls, and system diagrams.
                </p>
                <Button onClick={generateWorkflowDocument}>
                  <Download className="h-4 w-4 mr-2" />
                  Download Workflow Summary
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default AdminDashboard;
