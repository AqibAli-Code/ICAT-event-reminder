/**
 * Index page - Enterprise Admin Dashboard Layout
 * Sidebar is now fully wired up to handle navigation.
 */

import { useState, useEffect, useCallback, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import EventCard from "@/components/EventCard";
import EventForm from "@/components/EventForm";
import AlarmPopup from "@/components/AlarmPopup";
import CalendarView from "@/components/CalendarView";
import AlarmSoundSettings from "@/components/AlarmSoundSettings";
import { fetchUserEvents, deleteEvent, EventData } from "@/lib/supabase-helpers";
import { exportEventsToPdf } from "@/lib/export-events-pdf";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { 
  Plus, Search, CalendarDays, List, Settings, FileDown, 
  LayoutDashboard, Bell, LogOut, Menu, CheckCircle
} from "lucide-react";
import MotivationalQuote from "@/components/MotivationalQuote";
import StreakTracker from "@/components/StreakTracker";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

// UPDATED: Changed is_alarm_dismissed to is_triggered to match DB
type EventWithCategory = EventData & {
  id: string;
  is_triggered: boolean; 
  categories?: { name: string } | null;
};

const Index = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [events, setEvents] = useState<EventWithCategory[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<EventWithCategory | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [alarmEvent, setAlarmEvent] = useState<EventWithCategory | null>(null);
  const snoozedRef = useRef<Map<string, number>>(new Map());
  const [alarmSoundUrl, setAlarmSoundUrl] = useState<string | null>("preset:classic");
  
  const [activeTab, setActiveTab] = useState("list");

  useEffect(() => {
    if (!user) return;
    supabase
      .from("profiles")
      .select("alarm_sound_url")
      .eq("user_id", user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (data?.alarm_sound_url) setAlarmSoundUrl(data.alarm_sound_url);
      });
  }, [user]);

  const loadEvents = useCallback(async () => {
    if (!user) return;
    const { data, error } = await fetchUserEvents();
    if (error) {
      toast({ title: "Error loading events", description: error.message, variant: "destructive" });
      return;
    }
    setEvents((data as EventWithCategory[]) || []);
  }, [user, toast]);

  useEffect(() => {
    loadEvents();
  }, [loadEvents]);

  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel("user-events-realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "events" }, () => loadEvents())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user, loadEvents]);

  // UPDATED: Improved Alarm Checker logic using is_triggered
  useEffect(() => {
    const checkAlarms = () => {
      const now = Date.now();
      for (const event of events) {
        // Skip if already triggered
        if (event.is_triggered) continue;

        const eventTime = new Date(event.event_date).getTime();
        const snoozedUntil = snoozedRef.current.get(event.id);
        
        // Trigger if time has passed and it's within the last 2 minutes
        if (eventTime <= now && eventTime > now - 120000) {
          if (snoozedUntil && now < snoozedUntil) continue;
          setAlarmEvent(event);
          break;
        }
      }
    };
    checkAlarms();
    const interval = setInterval(checkAlarms, 15000); // Check every 15s for better accuracy
    return () => clearInterval(interval);
  }, [events]);

  // UPDATED: handleDismissAlarm now updates the database column
  const handleDismissAlarm = async () => {
    if (!alarmEvent) return;

    try {
      const { error } = await supabase
        .from("events")
        .update({ is_triggered: true })
        .eq("id", alarmEvent.id);

      if (error) throw error;

      setAlarmEvent(null);
      loadEvents(); // Refresh list to reflect triggered status
      toast({ title: "Alarm dismissed" });
    } catch (error: any) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  };

  const handleSnooze = (minutes: number) => {
    if (!alarmEvent) return;
    snoozedRef.current.set(alarmEvent.id, Date.now() + minutes * 60 * 1000);
    setAlarmEvent(null);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    const { error } = await deleteEvent(deleteTarget);
    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Event deleted" });
      loadEvents();
    }
    setDeleteTarget(null);
  };

  const filteredEvents = events.filter((e) =>
    e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.categories?.name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const nowVal = new Date();
  const upcoming = filteredEvents.filter((e) => new Date(e.event_date) >= nowVal);
  const past = filteredEvents.filter((e) => new Date(e.event_date) < nowVal);

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden font-sans text-slate-900">
      
      {/* SIDEBAR */}
      <aside className="w-64 bg-white text-gray-600 flex-col hidden md:flex border-r border-gray-200 shadow-xl z-10">
        <div className="h-16 flex items-center px-6 border-b border-gray-200 bg-white">
          <div className="w-8 h-8 bg-blue-600 rounded-md flex items-center justify-center mr-3 shadow-lg">
            <Bell className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold text-gray-900 tracking-tight">EventReminder</span>
        </div>
        
        <div className="flex-1 py-6 px-4 space-y-1 overflow-y-auto">
          <p className="px-2 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Main Menu</p>
          <button 
            onClick={() => setActiveTab("list")}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md font-medium transition-colors ${activeTab === "list" ? "bg-blue-600/10 text-blue-500" : "hover:bg-slate-900 hover:text-white"}`}
          >
            <LayoutDashboard className="w-4 h-4" />
            Dashboard
          </button>
          <button 
            onClick={() => setActiveTab("calendar")}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md font-medium transition-colors ${activeTab === "calendar" ? "bg-blue-600/10 text-blue-500" : "hover:bg-slate-900 hover:text-white"}`}
          >
            <CalendarDays className="w-4 h-4" />
            Calendar
          </button>
          <button 
            onClick={() => setActiveTab("settings")}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md font-medium transition-colors ${activeTab === "settings" ? "bg-blue-600/10 text-blue-500" : "hover:bg-slate-900 hover:text-white"}`}
          >
            <Settings className="w-4 h-4" />
            Settings
          </button>
        </div>

        <div className="p-4 border-t border-gray-200 bg-gray-50">
            <div className="flex items-center gap-3 mb-4 px-2">
              <div className="w-9 h-9 rounded-full bg-blue-100 border border-blue-200 flex items-center justify-center text-sm font-bold text-blue-700">
                {user?.email?.charAt(0).toUpperCase() || 'U'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">
                  {user?.email || 'Student Account'}</p>
                <p className="text-xs text-gray-500">Free Plan</p>
              </div>
            </div>
            <button 
              onClick={() => {
                localStorage.clear(); 
                sessionStorage.clear();
                window.location.replace("/"); 
              }}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-md bg-white border border-gray-200 hover:bg-gray-100 hover:text-red-600 text-gray-700 text-sm font-medium transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </button>
          </div>
      </aside>

      {/* MAIN CONTENT AREA */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden relative">
        <header className="md:hidden h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 z-10 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-blue-600 rounded flex items-center justify-center">
              <Bell className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="font-bold text-slate-900">EventReminder</span>
          </div>
          <button className="p-2 text-slate-600 hover:bg-slate-100 rounded-md">
            <Menu className="w-5 h-5" />
          </button>
        </header>

        <main className="flex-1 overflow-y-auto p-4 sm:p-8">
          <div className="max-w-6xl mx-auto space-y-8">
            
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-6">
              <div>
                <h1 className="text-3xl font-black tracking-tight text-slate-900">
                  {activeTab === "list" && "Overview"}
                  {activeTab === "calendar" && "Your Calendar"}
                  {activeTab === "settings" && "Preferences"}
                </h1>
                <p className="text-sm font-medium text-slate-500 mt-1 flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  You have {upcoming.length} upcoming tasks to handle.
                </p>
              </div>
              
              <div className="flex items-center gap-3 w-full lg:w-auto">
                <Button variant="outline" onClick={() => exportEventsToPdf(events, user?.email ?? undefined)} className="bg-white border-slate-200 text-slate-700 hover:bg-slate-50 font-semibold shadow-sm h-10 px-4">
                  <FileDown className="w-4 h-4 mr-2 text-slate-500" /> Export PDF
                </Button>
                <Button onClick={() => { setEditingEvent(null); setFormOpen(true); }} className="bg-slate-900 text-white hover:bg-slate-800 shadow-sm font-semibold h-10 px-4">
                  <Plus className="w-4 h-4 mr-2" /> New Event
                </Button>
              </div>
            </div>

            {activeTab === "list" && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-1"><StreakTracker events={events} /></div>
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-1"><MotivationalQuote /></div>
              </div>
            )}

            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center gap-4 bg-slate-50/50">
                  <TabsList className="bg-slate-200/50 p-1 rounded-lg md:hidden">
                    <TabsTrigger value="list" className="data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-md"><List className="h-4 w-4" /></TabsTrigger>
                    <TabsTrigger value="calendar" className="data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-md"><CalendarDays className="h-4 w-4" /></TabsTrigger>
                    <TabsTrigger value="settings" className="data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-md"><Settings className="h-4 w-4" /></TabsTrigger>
                  </TabsList>

                  <div className="hidden md:block text-sm font-semibold text-slate-400 uppercase tracking-widest">
                    {activeTab} View
                  </div>

                  <div className="relative w-full sm:w-72">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <Input placeholder="Search your events..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-9 bg-white border-slate-300 focus-visible:ring-1 focus-visible:ring-slate-900 rounded-md shadow-sm h-9" />
                  </div>
                </div>

                <div className="p-6">
                  <TabsContent value="list" className="m-0 space-y-8">
                    {upcoming.length > 0 && (
                      <section>
                        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 pl-1">Upcoming Tasks</h2>
                        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                          {upcoming.map((event) => <EventCard key={event.id} event={event} onEdit={() => { setEditingEvent(event); setFormOpen(true); }} onDelete={() => setDeleteTarget(event.id)} />)}
                        </div>
                      </section>
                    )}
                    {past.length > 0 && (
                      <section className="pt-2">
                        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 pl-1">Completed / Past</h2>
                        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                          {past.map((event) => <EventCard key={event.id} event={event} onEdit={() => { setEditingEvent(event); setFormOpen(true); }} onDelete={() => setDeleteTarget(event.id)} />)}
                        </div>
                      </section>
                    )}
                    {filteredEvents.length === 0 && (
                      <div className="flex flex-col items-center justify-center py-24 text-center border-2 border-dashed border-slate-200 rounded-xl bg-slate-50/50">
                        <div className="bg-white p-4 rounded-full shadow-sm border border-slate-100 mb-4"><CheckCircle className="h-8 w-8 text-slate-300" /></div>
                        <h3 className="text-lg font-bold text-slate-900 mb-1">All Caught Up</h3>
                        <p className="text-sm text-slate-500 mb-6 max-w-sm">You have no events matching your search criteria.</p>
                        <Button onClick={() => { setEditingEvent(null); setFormOpen(true); }} className="bg-slate-900 hover:bg-slate-800 text-white shadow-sm px-6">
                          <Plus className="h-4 w-4 mr-2" /> Add a Task
                        </Button>
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="calendar" className="m-0">
                    <div className="bg-slate-50 rounded-xl border border-slate-100 p-2">
                      <CalendarView events={events} onSelectEvent={(evt) => {
                        const full = events.find((e) => e.id === evt.id);
                        if (full) { setEditingEvent(full); setFormOpen(true); }
                      }} />
                    </div>
                  </TabsContent>

                  <TabsContent value="settings" className="m-0">
                    <div className="max-w-2xl">
                      <AlarmSoundSettings />
                    </div>
                  </TabsContent>
                </div>
              </Tabs>
            </div>
          </div>
        </main>
      </div>

      <EventForm open={formOpen} onClose={() => { setFormOpen(false); setEditingEvent(null); }} onSaved={loadEvents} editEvent={editingEvent} />
      <AlarmPopup open={!!alarmEvent} event={alarmEvent} alarmSoundUrl={alarmSoundUrl} onDismiss={handleDismissAlarm} onSnooze={handleSnooze} />
      
      <AlertDialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <AlertDialogContent className="rounded-xl border-slate-200 shadow-xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-slate-900">Delete Event</AlertDialogTitle>
            <AlertDialogDescription className="text-slate-500">Are you sure you want to permanently delete this event? This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-slate-200 text-slate-600 hover:bg-slate-50 font-medium">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700 text-white font-medium">Delete Permanently</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Index;