
-- Allow users to SELECT events they are assigned to via event_users
CREATE POLICY "Users can view assigned events"
ON public.events
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.event_users
    WHERE event_users.event_id = events.id
    AND event_users.user_id = auth.uid()
  )
);
