
-- Create junction table for multi-user events (admin can assign events to multiple users)
CREATE TABLE public.event_users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  event_id UUID NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  is_alarm_dismissed BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(event_id, user_id)
);

-- Enable RLS
ALTER TABLE public.event_users ENABLE ROW LEVEL SECURITY;

-- Users can see their own assigned events
CREATE POLICY "Users can view own event assignments"
  ON public.event_users FOR SELECT
  USING (auth.uid() = user_id);

-- Admins can do everything on event_users
CREATE POLICY "Admins can view all event assignments"
  ON public.event_users FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can insert event assignments"
  ON public.event_users FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete event assignments"
  ON public.event_users FOR DELETE
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Users can dismiss their own alarms
CREATE POLICY "Users can update own event assignments"
  ON public.event_users FOR UPDATE
  USING (auth.uid() = user_id);

-- Add created_by column to events to track who created it
ALTER TABLE public.events ADD COLUMN created_by UUID;

-- Enable realtime on events and event_users
ALTER PUBLICATION supabase_realtime ADD TABLE public.events;
ALTER PUBLICATION supabase_realtime ADD TABLE public.event_users;
