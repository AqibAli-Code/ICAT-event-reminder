
-- Create storage bucket for user alarm sounds
INSERT INTO storage.buckets (id, name, public) VALUES ('alarm-sounds', 'alarm-sounds', true);

-- Users can upload their own alarm sounds
CREATE POLICY "Users can upload own alarm sounds"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'alarm-sounds' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Users can view own alarm sounds
CREATE POLICY "Users can view own alarm sounds"
ON storage.objects FOR SELECT
USING (bucket_id = 'alarm-sounds' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Users can delete own alarm sounds
CREATE POLICY "Users can delete own alarm sounds"
ON storage.objects FOR DELETE
USING (bucket_id = 'alarm-sounds' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Add alarm_sound_url column to profiles for storing user preference
ALTER TABLE public.profiles ADD COLUMN alarm_sound_url TEXT;
-- Stores either a preset key like "preset:gentle" or a storage URL
