# Event Alert System

This repository is now organized into clear top-level folders:

- `frontend/`: React + Vite app, UI components, and frontend build config
- `backend/`: Supabase config, edge functions, and database migrations

## Folder layout

```text
event-alert-system-main/
	frontend/
		src/
		public/
		package.json
		vite.config.ts
		...
	backend/
		supabase/
			functions/
			migrations/
			config.toml
	README.md
```

## Run frontend locally

```sh
cd frontend
npm install
npm run dev
```

## Work with backend (Supabase)

```sh
cd backend/supabase
# run your supabase commands here, for example:
# supabase start
```
